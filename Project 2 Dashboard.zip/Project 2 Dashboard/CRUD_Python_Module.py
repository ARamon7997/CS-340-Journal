# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'Ch1cken$' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

   
    # Method for creating id's for each entry
    def entry_id(self):
        try: # The document is first queried for the first "animal_id"
            result = self.database.animals.find_one({}, sort = [("animal_id", -1)])
            if result and "animal_id" in result: # If there is one, and the id already exists
                return result["animal_id"] + 1   # where, an ID with an added value is made.  
            else: # Otherwise, a value of one is used.
                return 1
        except:
            return 1
    
            
    # Method for inserting documents into the "animals" collection
    def create(self, data):
        if data: # If data exists, a document insertion is attempted
            try:
                data["animal_id"] = self.entry_id() #first, an ID is injected into the document.
                self.database.animals.insert_one(data) # entry.
                print ("Insert successful") # If successful, this message should pop up, followed
                return True   # by a true flag.
            except: 
                print("Insert failure") # If unsuccessful, or issue(s) occur, then this message
                return False            # should come up, followed by false flag.
        return False

    # Query method for database searches
    
    def read(self, query={}):# If a query is is initiated, a search of the given fields is attempted
            try:
                if query is None:
                    query = {}
                result = self.database.animals.find(query)
                return list(result) # If successful, the results are listed.
            except exception as e:
                print("error", e)
                return [] # If unsuccessful, returns an empty list
        
    
     # Update method for updating animal entries
    
    def update(self, animal_id, data):
        if animal_id is not None and data: # If both an animal id and its data is found, and data is found in there
            try:
                result = self.database.animals.update_one({"animal_id": animal_id}, {"$set": data}) # The corresponding data is then updated.
                if result.modified_count > 0: # If a change was made to the entry
                    print("Update successful")
                    return True # A success message is outputted and the fields will return true, indicating a successful update.
                else: # If there were no updates
                    print("Update unsucessful / No changes made") # If there were no changes, or the input is inproperly inputted, 
                    return False                                  # an error is outputted, and will return false.
            except:
                print("Update failure") # In the event of a failure involving factors beyond input-related errors, a different error message is
                return False            # outputted.
        return False
    
    # Delete method for deleting animal entries
    
    def delete(self, animal_id): 
        if animal_id: # If the ID exists
            try:
                result = self.database.animals.delete_one({"animal_id": animal_id}) # An attempt will be made to delete the entry.
                if result.deleted_count > 0: # If a deletion had occured, a sucess message will be outputted and the entry will return true
                    print("Deletion successful")  # deleting the entry.
                    return True
                else:
                    print("Deletion unsucessful") # If there were no changes, an error is outputted, and will return false.
                    return False
            except:
                print("Deletion failure") # In the event of a failure involving factors beyond input-related errors, a different error message 
                return False              # is outputted.
        return False